// app.js-2-Tier Architecture Status Dashboard Version
const express=require('express');
const mysql=require('mysql2');
const app=express();
const port=3000;

// ==================================================================
// [중요] RDS 연결 정보 설정(여러분의 정보로 반드시 수정하세요!)
// ==================================================================
const dbConfig={
  host: '여기에_RDS엔드포인트주소_붙여 넣기', // 예: my-db.xxxx.rds.amazonaws.com
  user: 'admin',                          // 마스터 사용자명
  password: '여러분의_비밀번호',                // 마스터 암호
  database: 'MyDB'                        // 초기 DB 이름
};

// 커넥션 풀 생성(실무 권장 방식)
const pool=mysql.createPool(dbConfig);

app.get('/',(req, res) => {
  // DB에서 간단한 쿼리 실행(현재 시간 및 버전 가져오기)
  pool.query('SELECT NOW() as now, VERSION() as version',(err, results) => {
    if(err) {
        // 연결 실패 시 보여줄 에러 페이지 스타일링
        const errorHtml=`
        <div style="font-family: sans-serif; text-align: center; padding: 50px;">
            <h1 style="color: #D32F2F;">🚫 DB 연결 실패</h1>
            <p style="font-size: 1.2em; color: #555;">RDS 접속 정보를 다시 확인해 주세요.</p>
            <div style="background: #f8d7da; color: #721c24; padding: 20px; border-radius: 5px; display: inline-block; text-align: left;">
                <strong>Error Details:</strong><br>
                <code style="white-space: pre-wrap;">${err.message}</code>
            </div>
        </div>`;
        res.status(500).send(errorHtml);
      return;
    }

    const dbInfo=results[0];

    // =======================================================
    // [성공 시] 멋진 대시보드 HTML & CSS 렌더링
    // =======================================================
    const successHtml=`
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <title>AWS 2-Tier 아키텍처 상태</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .dashboard-card { background: white; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); overflow: hidden; width: 600px; max-width: 90%; }
            .header { background: linear-gradient(135deg, #34d058 0%, #28a745 100%); color: white; padding: 30px; text-align: center; }
            .header h1 { margin: 0; font-size: 2.2em; }
            .header p { margin: 10px 0 0; font-size: 1.1em; opacity: 0.9; }
            .content { padding: 30px; }
            .architecture-diagram { display: flex; justify-content: space-around; align-items: center; margin-bottom: 30px; padding: 20px; background: #f8f9fa; border-radius: 10px; }
            .component { text-align: center; padding: 15px; border: 2px solid #e9ecef; border-radius: 10px; background: white; width: 40%; }
            .component h3 { margin: 0 0 10px; color: #333; }
            .arrow { font-size: 2em; color: #28a745; font-weight: bold; }
            .info-table { width: 100%; border-collapse: collapse; }
            .info-table th, .info-table td { padding: 12px; text-align: left; border-bottom: 1px solid #e9ecef; }
            .info-table th { background-color: #f8f9fa; color: #555; width: 40%; }
            .status-badge { background: #d4edda; color: #155724; padding: 5px 10px; border-radius: 20px; font-weight: bold; font-size: 0.9em; }
            .footer { text-align: center; padding: 20px; color: #777; font-size: 0.9em; border-top: 1px solid #eee; }
        </style>
    </head>
    <body>
        <div class="dashboard-card">
            <div class="header">
                <h1>🎉 연결 성공! <br>(Connection Success)</h1>
                <p>안전한 AWS 2-Tier 아키텍처가 정상 작동 중입니다.</p>
            </div>
            <div class="content">
                <div class="architecture-diagram">
                    <div class="component">
                        <div style="font-size: 3em;">🖥️</div>
                        <h3>EC2 Web Server</h3>
                        <p>(Node.js App)</p>
                    </div>
                    <div class="arrow">⟺ Secure Link ⟺</div>
                    <div class="component">
                        <div style="font-size: 3em;">🗄️</div>
                        <h3>RDS Database</h3>
                        <p>(MySQL)</p>
                    </div>
                </div>

                <h3 style="color: #333;">데이터베이스 연결 상세 정보</h3>
                <table class="info-table">
                    <tr>
                        <th>연결 상태(Status)</th>
                        <td><span class="status-badge">✅ Active & Healthy</span></td>
                    </tr>
                    <tr>
                        <th>DB 엔드포인트(Host)</th>
                        <td><code>${dbConfig.host}</code></td>
                    </tr>
                    <tr>
                        <th>사용자/DB명</th>
                        <td>${dbConfig.user}/${dbConfig.database}</td>
                    </tr>
                    <tr>
                        <th>DB 서버 버전</th>
                        <td>${dbInfo.version}</td>
                    </tr>
                    <tr>
                        <th>DB 서버 현재 시간(쿼리 결과)</th>
                        <td style="color: #007bff; font-weight: bold;">${dbInfo.now}</td>
                    </tr>
                </table>
            </div>
            <div class="footer">
                AWS Cloud BootCamp-Chapter 5 Lab Project
            </div>
        </div>
    </body>
    </html>
    `;
    res.send(successHtml);
  });
});

app.listen(port,() => {
  console.log(`멋진 대시보드 웹 서버가 포트 ${port}에서 실행 중입니다.`);
});