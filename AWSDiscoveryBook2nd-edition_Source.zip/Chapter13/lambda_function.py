import json
import boto3

# 1. Bedrock 클라이언트 준비 (두뇌 연결)
bedrock = boto3.client( service_name='bedrock-runtime', region_name='us-east-1' )

def lambda_handler(event, context):
    try:
        # 2. 사용자 질문 받기 (API Gateway를 통해 들어온 데이터)
        # body가 문자열로 오면 JSON으로 변환, 없으면 빈 딕셔너리
        request_body = json.loads(event.get('body', '{}'))
        user_question = request_body.get('question', '자기소개를 간단히 해줘')
        
        # 시스템 프롬프트(성격) 설정 - 없으면 기본 비서
        system_persona = request_body.get('system_prompt', '당신은 도움이 되는 AI 비서입니다.')

        # 3. Bedrock(Claude 3)에게 보낼 요청서 작성
        model_id = "us.anthropic.claude-3-sonnet-20240229-v1:0"
        
        payload = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "system": system_persona, 
            "messages": [
                {
                    "role": "user",
                    "content": user_question
                }
            ]
        }

        # 4. 모델 호출 (질문 던지기)
        response = bedrock.invoke_model(
            modelId=model_id,
            body=json.dumps(payload)
        )

        # 5. 결과 해석 (답변 꺼내기)
        response_body = json.loads(response.get('body').read())
        ai_answer = response_body['content'][0]['text']

        # 6. 사용자에게 답변 돌려주기 (CORS 헤더 포함)
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*', # 모든 곳에서 접속 허용
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({'answer': ai_answer}, ensure_ascii=False)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)}, ensure_ascii=False)
        }
